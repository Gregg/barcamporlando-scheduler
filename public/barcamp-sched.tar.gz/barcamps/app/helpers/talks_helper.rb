module TalksHelper
end
