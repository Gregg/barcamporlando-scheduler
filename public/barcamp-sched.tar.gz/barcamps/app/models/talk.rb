class Talk < ActiveRecord::Base
  belongs_to :event
end
