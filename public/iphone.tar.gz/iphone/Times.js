
iSchedule.Times = function(config) {
	this.data;		// Array of locations (conference rooms)
	
}

iSchedule.Times.prototype.getData = function(locID) {
	console.log('Times: getData()');
	
	var oCallback = {
	success: function(oRequest,oResponse) {
		//console.log(oResponse);
		//console.log("Length = " + oResponse.results.length);
		this.data = iSchedule.dataSourceDoBeforeParseData(oRequest, oResponse.results);
		console.log(this.data, this);
	},
	failure: function(oRequest,oResponse) {
		console.log("Datasource callback failure");
		console.log(oResponse);
	},
	scope: this
	};
	
	iSchedule.syncRequest(iSchedule.SERVER+'events/'+ locID + '/talks.json', oCallback);
	//this.ds.sendRequest('events.json', oCallback);
}

iSchedule.Times.prototype.numberOfRows = function() {
	// The List calls this dataSource method to find out how many rows should be in the list.
	return this.data ? this.data.length : 0;
}

iSchedule.Times.prototype.prepareRow = function(rowElement, rowIndex, templateElements) {
	if(templateElements.Time) {
		templateElements.Time.innerText = this.data[rowIndex].starts_at;
	}
	if(templateElements.Topic) {
		templateElements.Topic.innerText = this.data[rowIndex].topic;
	}
	if(templateElements.Speaker) {
		templateElements.Speaker.innerText = this.data[rowIndex].speaker;
	}
	
}

