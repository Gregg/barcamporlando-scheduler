


/********** Constants ******************/
iSchedule.SERVER = "http://0.0.0.0:3000/";

iSchedule.createiSchedule = function() {
	this.mylocation = new iSchedule.Locations();	// iSchedule.Locations
	this.mytimes = new iSchedule.Times();

	this.view = document.getElementById('list');
	YAHOO.util.Event.addListener(this.view, "click", this.locationClick)
}

iSchedule.createiSchedule.prototype.locationClick = function(event) {
	console.log("locationClick: ", event, this);
	//iSchedule.setLocation();
	
	var locEl, locID;
	if(event.target.hasAttribute('locationid')) {
		locEl = event.target;
	}
	else {
		locEl = YAHOO.util.Dom.getAncestorBy(event.target, function(el) {
			if(el.hasAttribute('locationid') && el != event.curentTarget) {
				return true;
			}
			else return false;
		});
	}
	locID = locEl.getAttribute('locationid')
	//console.log("Location id: ", locID, locEl);
	
	//iSchedule.detailController.setRepresentedObject(locID);
	barcamp.mytimes.getData(locID);
	var timeslist = document.getElementById('list1').object;
	console.log(timeslist);
	timeslist.reloadData();
	var browser = document.getElementById('browser').object;
	// The Browser's goForward method is used to make the browser push down to a new level.  Going back to previous levels is handled automatically.
	browser.goForward(document.getElementById('detailLevel'), iSchedule.locIDtoName(locID));
	

}

iSchedule.locIDtoName = function(locID) {
	console.log("locIDtoName: ", locID)
	if(locID == 1) {
		return "Slingapours";
	}
	else if(locID == 2) {
		return "One Eyed Jacks";
	}
	else if(locID == 3) {
		return "Courtyard Discussions";
	}
	
	
}

/********* Class Methods ****************/

iSchedule.dataSourceDoBeforeParseData = function(oRequest, oFullResponse) {
	// console.log("doBeforeParseData: ", oFullResponse);
	//return eval(oFullResponse);
	try {
		var jsarray = YAHOO.lang.JSON.parse(oFullResponse);
	}
	catch(e) {
		console.log("Exception in dataSourceDoBeforeParseResponse", e);
	}
	return jsarray;
}

iSchedule.syncRequest = function(url, oCallback) {
	var request = new XMLHttpRequest();
	request.open("GET", url, false);
	console.log("syncRequest: ", url)
	request.send(null);
	
	if(request.status == 200) {
		// we got a repsonse
		if(oCallback && oCallback.success) {
			if(!oCallback.scope) {
				oCallback.success(url, {results: request.responseText})
			}
			else {
				oCallback.success.apply(oCallback.scope, [url, {results: request.responseText}])
			}
		}
	}
	else {
		 if(oCallback && oCallback.failure) {
			oCallback.success(url, {error: request.status})
		}
	}
	
}
