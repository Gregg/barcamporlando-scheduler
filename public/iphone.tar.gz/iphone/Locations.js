
iSchedule.Locations = function(config) {
	this.data;		// Array of locations (conference rooms)
	this.getData();
}

iSchedule.Locations.prototype.getData = function() {
	console.log('Locations: getData()');
	
	var oCallback = {
	success: function(oRequest,oResponse) {
		//console.log(oResponse);
		//console.log("Length = " + oResponse.results.length);
		this.data = iSchedule.dataSourceDoBeforeParseData(oRequest, oResponse.results);
		console.log(this.data, this);
	},
	failure: function(oRequest,oResponse) {
		console.log("Datasource callback failure");
		console.log(oResponse);
	},
	scope: this
	};

	iSchedule.syncRequest(iSchedule.SERVER+'events.json', oCallback);
	//this.ds.sendRequest('events.json', oCallback);
}

iSchedule.Locations.prototype.initData = function(data) {
	var ds = new YAHOO.util.DataSource(iSchedule.SERVER);
	ds.responseType = YAHOO.util.DataSource.TYPE_JSARRAY;
	
	ds.responseSchema = {
		fields: [
			{ key: 'name' },
			{ key: 'id' },
			{ key: 'updated_at' },
			{ key: 'starts_at' },
			{ key: 'ends_at' },
			{ key: 'created_at' }
		]
	};
	ds.doBeforeParseData = iSchedule.dataSourceDoBeforeParseData;
	
	this.ds = ds;
}

iSchedule.Locations.prototype.numberOfRows = function() {
	// The List calls this dataSource method to find out how many rows should be in the list.
	return this.data.length;
},

iSchedule.Locations.prototype.prepareRow = function(rowElement, rowIndex, templateElements) {
	if(templateElements.rowTitle) {
		templateElements.rowTitle.innerText = this.data[rowIndex].name;
	}
	
	if(rowElement) {
		rowElement.setAttribute("LocationID", this.data[rowIndex].id);
	}
}

